<?php
	require_once ('lib/content.php');
	$header=new header_content;
	$body=new body;
	/*$navbar=new navbar;
	$index=new index;	
	$productCat=new productCat;			
	$itemProduct=new itemProduct;	
	$contacts=new contacts;
	$card=new card;	
	$checkout=new checkoutForm;
	$plug=new plug;	*/
	$footer=new footer;
?>