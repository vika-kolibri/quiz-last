<?php
	class header_content {
		
		public function content($result){
?>
<!--<!doctype html>-->
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="./css/main.css">
    <link rel="stylesheet" href="./bootstrap/bootstrap-5.1.1-dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">

    <title>
		<?php 
			while ($row=$result->fetch()){
				echo $row["text"];
			}
		?>
	</title>
    <!--<link rel="stylesheet" href="./bootstrap/bootstrap-5.1.1-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/main.css">
    <link rel="stylesheet" href="./quiz.html">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>-->
   
</head>
<body>
<?php
		}
	};
?>
<?php 
	class body {
		
		public function indexContent($bullits, $buttonText){
?>
 <header class="header">
        <div class="col-12" >
            <div class="row">
                <div class="col-md-12 ">
                    <p class="text-center">BelWebStudio - студия WEB-разработки</p>
                </div>          
            </div>           
        </div>
    </header>

<main class="main">
    <div class="container">   
            <div class="row col-md-12 lx-12 mt-5">
                <div class="title">
                    <h1 class="title1">Ответьте на 2 простых вопроса </h1>
                    <h3 class="title2">и получите пошаговый гайд “Как продавать <br> через сайт, несмотря ни на какой кризис”</h3>   
                </div>
            </div>
    </div>
  
  </div>


<div class="container">
    <div class="row mb-5">
        <div class="col-lg-7">
            <div class="fonm ">
                <img class="h" src="./img/back new.png" alt="">
            </div>   
        </div>
        <div class="col-lg-5">
            <ul class="w">
				<?php 
					while ($row=$bullits->fetch()){
						echo '<li class="pt-1">'.$row["text"].'</li>';
					}
				?>
            <!--<li class="pt-1">Обзор доступных инструментов для первичного анализа конкурентов</li>
            <li class="pt-1">Рекомендации по выбору типа сайта для Вашего бизнеса</li>
            <li class="pt-1">Советы, как выбрать разработчика и не облажаться</li>-->
            </ul>
            <div class="col-lg-11">
                <div class="row col">
                    <a  id="btn1" style="border-radius: 37px; padding: 17px 55px ; font-size: 24px; line-height: 29px;" class="btn btn-primary" href="quiz1.php" role="button">
						<?php 
							while ($row=$buttonText->fetch()){
								echo $row["text"];
							}
						?>
					</a>
                </div>               
            </div>
        </div>
    </div>
</div>
</main> 
<?php
		}
		
		public function quizContent($question, $answers, $url, $progress, $checkbox_value){
?>
<header class="header">
    <div class="container">
        <div class="col-xxl-12" >
            <div class="row">
                <div class="col-md-12 col-xxl-12 mb-5">
                    <p class="text-center">BelWebStudio - студия WEB-разработки</p>
                </div>          
            </div>           
        </div>
    </div>
</header>

<main class="main">
    <div class="container">
        <div class="quiz">
			<form method="post" action="<?php echo $url;?>">
            <div class="row col-md-12 mt-5">
                <div class="col col-md-12">
                    <div class="title">
                         <h4>
							<?php 
								while ($row=$question->fetch()){
									echo $row["text"];
								}
							?>
						</h4>
                    </div>
                </div>
				<?php
					while ($row=$answers->fetch()){
						echo '<div class="container">
							<div class="row col-md-8 col-xxl-8 col-lg-8">
								<label class="label">
									
									<div class="row col-lg-12 col-xxl-12 mt-3">
										<div class="border">   
											<div class="col col-lg-1 p-3">
												<input type="checkbox" class="checkbox" name="quiz[]" value="'.$checkbox_value.'">
												<div class="radius"></div>
											</div>
											<div class="col-md-5 col-lg-5 col-xxl-5 col-sm-5 col-xs-5 p-2">
												<p id="lp" class="col">'.$row["text"].'</p>
											</div>
											<div class="col col-lg-1 p-3">
												<a href="#" id="qwes"><img id="imgcont" class="qwes" src="./img/explain-me.png" alt="explain">
													<div id="content" class="block-content">
														<p></p>
													</div>
												 </a>
											   
											</div>    
										</div>
									</div>
								   
								</label>
							</div>    
						</div>';
						$checkbox_value++;
					}
				?>  
				</div>
				<div class="container ">
                <div class="d-flex justify-content-between">
				
                    <div class="row col-lg-9 ">
                        <div class="row col-lg-6">
                            <!-- new  начало бл-ка progress-bar-->
                        <div id="progress-bar-1" class="progress-bar">
                                <span class="blue"><?php echo $progress;?>%</span>
                                <div class="progress">
							        <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo $progress;?>" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $progress;?>%"></div>
							    </div> 
                        </div> 
							<!-- new  конец бл-ка progress-bar-->
							 
					
							
                        </div>
                        <div class="row col-lg-2">
                            <div class="back">
                                <a id="back" onclick="javascript:history.back(); return false;" href=""><img class="img-back" src="./img/back-button.png" alt=""></a>
                                <!--<a  id="btn-back" onclick="javascript:getCheckedCheckBoxes();" style="border-radius: 37px; padding: 17px 55px ; font-size: 24px; line-height: 29px;" class="btn btn-primary" href="<?php echo $url; ?>" role="button">Далее</a>
								--><button type="submit"  id="btn-back" style="border-radius: 37px; padding: 17px 55px ; font-size: 24px; line-height: 29px;" class="btn btn-primary">Далее</a>
							</div>
                        </div>      
                    </div>
                </div>               
            </div>
        </div>
        </div>
		</form>
        </div>
    </div>    
</main>    
<?php
			//$_SESSION['quiz']='QUIIIIZZZZ';
		}
		public function lastContent($messengers, $progress){
?>
<header class="header">
        <div class="col-12" >
            <div class="row">
                <div class="col-md-12">
                    <p class="text-center">BelWebStudio - студия WEB-разработки</p>
                </div>          
            </div>           
        </div>
    </header>

<main class="main">
    <div class="container">
        <div class="row  mt-5">
            <div class="col-lg-6">
                <div id="fonm" class="fonm">
                    <img class="h" src="./img/back new.png" alt="">
                </div>  
                <!-- new  начало бл-ка progress-bar-->
                <div id="progress-bar" class="progress-bar">
                    <span class="blue">98%</span>
                    <div class="progress">
						<div class="progress-bar" role="progressbar" aria-valuenow="<?php echo $progress;?>" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $progress;?>%">
						</div>
					</div> 
                </div>  


                <!-- new  конец бло-ка progress-bar-->
                <div id="progress-bar" class="progress-bar">
                    <!--<img src="img/progress-bar.svg" alt="progress-bar">-->
                    
					 
                </div>  
            </div>
            <div class="col-lg-6 col-md-6 ">
                        <div class="title">
                            <h1 id="tit3">Спасибо за прохождение теста!</h1>
                            <h3 id="tit4">остался последний шаг</h3>
                        </div> 
                        <!--начало блока введите ваш телефон-->
                        <div id="adress" class="col col-md-9 col-lg-9 col-xxl-9" >
                            <div class="mail">
                                <p class="" id="pdf">Введите номер телефона:</p>
                            </div>
                            <?php  
                                $i='';
                                ?>    

                            <div class="mb-3">
                                <!--добавили input value-->  
                                <input value="<?php $i; ?>" id="e-mail" type="tel-nam" class="form-control namb-tel clickyradio" id="exampleFormControlInput1" placeholder="+375(--) --- -- --">
                            </div>                      
                        </div>
                      
                        <!--конец блока введите ваш телефон-->
                        <div class="col-lg-8 col-md-6 ">
                            <div class="title">
                                <p class="text-center" id="pdf1">Выберите мессенджер, <br> чтобы открыть доступ к pdf-файлу</p> 
                            </div>
                        </div> 
                        <div class="text-center">
                        <!--пока не ввели телефонный номер мессенджеры должны быть не активные... создаем переменную--> 
                      
                            <?php  
                                while ($row=$messengers->fetch()){
                                    echo '<a id="icon" href="'.$row["text"].'"><img src="./img/'.$row["img"].'"></a>';
                                }
                                  /* if ($i){
                                while ($row=$messengers->fetch()){
                                    echo '<a id="icon" href="'.$row["text"].'"><img src="./img/'.$row["img"].'"></a>';
                                }   
                                }
                                else {                          
                                    while ($row=$messengers->fetch()){
                                        echo '<a id="icon"><img src="./img/'.$row["img"].'"></a>';
                                    }
                                };
                                   */
                            ?>  
                        
                        </div>
                        <!--
                            <a id="icon" href="#"><img src="./img/viber.png" alt="viber"></a>
                            <a id="icon" href="#"><img src="./img/telegram.png" alt="telegram"></a>
                            <a id="icon" href="#"><img src="./img/WhatsApp_Logo.png" alt="WhatsApp"></a> -->                                              
                        
    
                
                    <div id="adress" class="col col-md-9 col-xxl-9 ">
                        <div class="mail">
                            <p class="" id="pdf">или получите на электронную почту:</p>
                        </div>
                        <!-- начало- рсширили блок е-mail -->
                        <div class="mb-3">
                            <input id="e-mail" type="email" class="form-control" id="exampleFormControlInput1" placeholder="Ваш e-mail">
                        </div>
                          <!-- конец- рсширили блок е-mail -->
                        
                        <div class="row col">
                            <a id="btn4" style="border-radius: 37px; padding: 17px 55px ; font-size: 24px; line-height: 29px;" class="btn btn-primary" href="thanks.php" role="button">Получить PDF-файл</a>
                            <div id="inp" class="row col-md-12 mt-2">
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                    <label class="form-check-label" for="exampleCheck1"><a href=""><span class="ton"> Вы соглашаетесь с условиями <br> обработки </span>персональных данных</a></label>
                                </div>
                            </div>   
                        </div>
                                            
                    </div>
            </div>
        </div>
    </div>
</main>

<?php
		}
		public function thanksContent(){
?>

<header class="header">
        <div class="col-12" >
            <div class="row">
                <div class="col-md-12">
                    <p class="text-center">BelWebStudio - студия WEB-разработки</p>
                </div>          
            </div>           
        </div>
        <div class="col-12" >
            <div class="row">
                <div class="col-md-12">
                    <div class="fon-test">
                        <p class="text-center">Тест пройден успешно! <br> PDF-файл отправлен Вам в Телеграм</p>
                    </div>
                </div>          
            </div>           
        </div>
    </header>
<main class="main">
    <div  id="th" class="container">
        <div class="row ">
            <div class="col-lg-7 col-md-3">
                <div class="fonm ">
                    <p>Елена,<br> <span class="black"> Интернет-Маркетолог</span></p>
                    <img class="g" src="img/woman.png" alt="">
                </div>   
            </div>
            <div class="col-lg-5 col-md-2 text-center">
                        <div class="title-one">
                            <h2 id="tit1" class="title3">Не спешите уходить,<br> мы подготовили для Вас <br> специальное предложение:</h2>
                            <h2 id="tit2" class="title4">Консультация маркетолога <span class="black">со скидкой 50%</span></h2>   
                        </div>
                <ul id="list-2" class="d-flex flex-column bd-highlight mb-3">
                    <li id="pt-2"><span class="black">Первичный аудит </span>Вашего бизнеса</li>
                    <li id="pt-2"><span class="black">Рекомендации </span> с чего начать <br> путь в Интернете</li>
                    <li id="pt-2"><span class="black">Помощь </span> в выявллении ваших <br>  сильных сторон</li>
                </ul>
                            <a  id="btn1" style="border-radius: 37px; padding: 17px 55px ; font-size: 24px; line-height: 29px;" class="btn btn-primary" href="#" role="button">Заказать консультацию</a>
                       
                        <div id="btn-w" class="row col-md-12 mt-2">
                            <a class="btn-thanks" href="#" role="button">Нет, спасибо</a>
                        </div>                        
            </div>
        </div>
    </div>
</main> 

<?php
		}
		
	}
?>
<?php
	class footer {
		
		public function content(){
?>
<footer class="bg-white">
    <div id="foot" class="">
        <div class="container ">
            <div class="row col-md-12">    
                <div class="col col-lg-8">
                    <a href="https://belwebstudio.by/"><img src="./img/logo.png" alt="logo"></a>
                </div>
                <div class="col lg-4">
                    <div class="tel">
                        <a href="tel:+375292389851">+375 (29) <span class="bw">238-98-51</span> </a>
                    </div>                   
                </div>      
            </div>
        </div> 
    </div>      
</footer>
<script src="./js/script.js"></script>
<script src="./bootstrap/bootstrap-5.1.1-dist/js/bootstrap.min.js"></script>


<script>	
function getCheckedCheckBoxes() {
  var checkboxes = document.getElementsByClassName('checkbox');
  var checkboxesChecked = []; // можно в массиве их хранить, если нужно использовать 
  for (var index = 0; index < checkboxes.length; index++) {
     if (checkboxes[index].checked) {
        checkboxesChecked.push(checkboxes[index].value); // положим в массив выбранный
        alert(checkboxes[index].value); // делайте что нужно - это для наглядности
     }
  }
  return checkboxesChecked; // для использования в нужном месте
}
</script>
</body>
</html>
<?php
		}
	};
?>