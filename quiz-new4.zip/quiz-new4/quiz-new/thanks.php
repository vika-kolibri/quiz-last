<?php
session_start();
	require_once('lib/require_class.php');
	require_once('lib/query_model.php');
	require_once ('lib/db_connect.php');
	$connect=new db_connect;
	$connect=$connect->connect();
	if (!$connect){
		echo 'Ошибка';			
		exit;
	} else {
		$options=new model;
		$title=$options->selectTitle($connect, '8');
		$bullits=$options->selectBullits($connect, 'thanks');		
		$header->content($title);
		$body->thanksContent();		
		$footer->content();
	}
?>