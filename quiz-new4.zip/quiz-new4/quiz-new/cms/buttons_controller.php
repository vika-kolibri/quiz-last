<?php
session_start();
	require_once('includes/db_connect.php');
	require_once('includes/content.php');
	require_once('buttons_model.php');
	require_once('includes/auth.php');
	
	$check=new auth;
	$check=$check->check_admin_user();
	$header=new header_content;
	$footer=new footer_content;
	
	if ($check){	
		$connect=new db_connect;		
		$buttons=new view_buttons;
		$buttons_options=new buttons_model;
		$navbar=new navbar;
		$url=new admin_url;
		$connect=$connect->connect();
		if (!$connect){
			$header->content();
			echo "Error!";
			$footer->content();
		} else {
			$param=htmlspecialchars(strip_tags($_GET['param']));
			$header->content();
			$navbar->nav();
			switch ($param){
				case '':
					$select=$buttons_options->select_buttons($connect);
					if (!$select){
						echo "Error!";
						break;
					} else {
						$buttons->options();
						$buttons->buttons($select);
					}
				break;
				case 'create_form':
					$form=new buttons_form;
					$form->form_header('buttons_controller.php?param=create');
					$form->form_body ();
					$form->form_footer();
				break;
				case 'create':
					//$destination=htmlspecialchars(strip_tags($_POST['destination']));
					$text=htmlspecialchars(strip_tags($_POST['text']));
					$insert=$buttons_options->create_button($connect, $text);
					if (!$insert){
						echo "Error!";
					} else {
						echo '<div class="left">Текст кнопки создан!</div>';
						$url->url('buttons_controller.php', 'Назад');
					}
				break;
				
				case 'edit_form':
					$form=new edit_buttons_form;
					$buttonid=htmlspecialchars(strip_tags($_POST['buttonid']));
					$select=$buttons_options->select_button_by_id($connect, $buttonid);
					if (!$select){
						echo "Error!";
				break;
					} else {
						$form->form_header('buttons_controller.php?param=edit');
						$form->form_body ($select);
						$form->form_footer();
					}
				break;
				case 'edit':
					$buttonid=htmlspecialchars(strip_tags($_POST['buttonid']));
					//$destination=htmlspecialchars(strip_tags($_POST['destination']));
					$text=htmlspecialchars(strip_tags($_POST['text']));
					//$catdescription=htmlspecialchars(strip_tags($_POST['catdescription']));
					$update=$buttons_options->edit_button($connect, $buttonid, $text);
					if (!$update){
						echo "Error!";
					} else {
						echo '<div class="left">Текст кнопки отредактирован!</div>';
						$url->url('buttons_controller.php', 'Назад');
					}
				break;
				
				case 'delete':
					$buttonid=htmlspecialchars(strip_tags($_POST['buttonid']));
					$delete=$buttons_options->delete_button($connect, $buttonid);
					if (!$delete){
						echo "Error!";
					} else {
						echo '<div class="left">Текст кнопки удален!</div>';
						$url->url('buttons_controller.php', 'Назад');
					}
				break;
				default:
					echo "Wrong arg!";
				break;
			}
			$footer->content();
		}
	} else {
		$header->content();
		echo '<center><h3>У Вас нет прав для просмотра этой страницы!</h3></br><a href="login.php">Вход</a></center>';		
		$footer->content();
	}
?>