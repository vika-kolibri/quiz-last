<?php 
	class users_model{
		public function select_users($connect){
			$select=$connect->prepare("select * from `users`");
			if (!$select->execute())
				return 0;
			return $select;
		}
		public function create_user($connect, $username, $password){
			$insert=$connect->prepare("insert into `users` (login, pass) values ('$username', sha1('$password'))");
			if (!$insert->execute()) {
				return 0;
			} else {
				return 1;
			}			
		}
		public function delete_user($connect, $userid){
			$delete=$connect->prepare("delete from `users` where `id`='$userid'");
			if (!$delete->execute())
				return 0;
			return 1;
		}
	}
?>			