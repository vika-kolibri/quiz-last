<?php
session_start();
	require_once('includes/db_connect.php');
	require_once('includes/content.php');
	require_once('titles_model.php');
	require_once('includes/auth.php');
	
	$check=new auth;
	$check=$check->check_admin_user();
	$header=new header_content;
	$footer=new footer_content;
	
	if ($check){	
		$connect=new db_connect;		
		$titles=new view_titles;
		$titles_options=new titles_model;
		$navbar=new navbar;
		$url=new admin_url;
		$connect=$connect->connect();
		if (!$connect){
			$header->content();
			echo "Error!";
			$footer->content();
		} else {
			$param=htmlspecialchars(strip_tags($_GET['param']));
			$header->content();
			$navbar->nav();
			switch ($param){
				case '':
					$select=$titles_options->select_titles($connect);
					if (!$select){
						echo "Error!";
						break;
					} else {
						$titles->options();
						$titles->titles($select);
					}
				break;
				case 'create_form':
					$form=new title_form;
					$form->form_header('titles_controller.php?param=create');
					$form->form_body ();
					$form->form_footer();
				break;
				case 'create':
					$destination=htmlspecialchars(strip_tags($_POST['destination']));
					$text=htmlspecialchars(strip_tags($_POST['text']));
					$insert=$titles_options->create_title($connect, $destination, $text);
					if (!$insert){
						echo "Error!";
					} else {
						echo '<div class="left">Заголовок создан!</div>';
						$url->url('titles_controller.php', 'Назад');
					}
				break;
				
				case 'edit_form':
					$form=new edit_title_form;
					$titleid=htmlspecialchars(strip_tags($_POST['titleid']));
					$select=$titles_options->select_title_by_id($connect, $titleid);
					if (!$select){
						echo "Error!";
				break;
					} else {
						$form->form_header('titles_controller.php?param=edit');
						$form->form_body ($select);
						$form->form_footer();
					}
				break;
				case 'edit':
					$titleid=htmlspecialchars(strip_tags($_POST['titleid']));
					$destination=htmlspecialchars(strip_tags($_POST['destination']));
					$text=htmlspecialchars(strip_tags($_POST['text']));
					//$catdescription=htmlspecialchars(strip_tags($_POST['catdescription']));
					$update=$titles_options->edit_title($connect, $titleid, $destination, $text);
					if (!$update){
						echo "Error!";
					} else {
						echo '<div class="left">Заголовок отредактирован!</div>';
						$url->url('titles_controller.php', 'Назад');
					}
				break;
				
				case 'delete':
					$titleid=htmlspecialchars(strip_tags($_POST['titleid']));
					$delete=$titles_options->delete_title($connect, $titleid);
					if (!$delete){
						echo "Error!";
					} else {
						echo '<div class="left">Заголовок удален!</div>';
						$url->url('titles_controller.php', 'Назад');
					}
				break;
				default:
					echo "Wrong arg!";
				break;
			}
			$footer->content();
		}
	} else {
		$header->content();
		echo '<center><h3>У Вас нет прав для просмотра этой страницы!</h3></br><a href="login.php">Вход</a></center>';		
		$footer->content();
	}
?>