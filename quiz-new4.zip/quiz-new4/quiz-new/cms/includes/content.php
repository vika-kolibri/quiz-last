<?php
	class loginForm {
		public function form(){
?>
<!doctype html>
<html lang="ru">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">    
    <title>Вход</title>
    <!-- Bootstrap core CSS -->
	<!--<link href="bootstrap-4.3.1-dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">   
	<link href="bootstrap-4.3.1-dist/css/style.css" rel="stylesheet">   -->
	<link href="bootstrap-4.3.1-dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="bootstrap-4.3.1-dist/css/style.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-glyphicons.css">
  </head>
<body>
<div class="row">
<div class="col-md-4">
</div>
<div class="col-md-4">
<form class="form" method="post" action="index.php">
	<div class="form-group">
		<label for="login">Логин:</label>
		<input type="text" class="form-control" id="login" name="login" placeholder="Логин">    
	 </div>
	<div class="form-group">
		<label for="password">Пароль:</label>
		<input type="password" class="form-control" id="password" name="password" placeholder="Пароль">    
	</div>
	<center><button type="submit" class="btn btn-primary">Войти</button></center>
</form>
</div>
</div>
</body>
</html>
<?php
		}
	};
?>
<?php
	class header_content {
		
		public function content(){
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">    
    <title>Система управления</title>
    <!-- Bootstrap core CSS -->
	<link href="bootstrap-4.3.1-dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">   
	<link href="bootstrap-4.3.1-dist/css/style.css" rel="stylesheet">    

  </head>
<body>
<?php
		}
	};
?>
<?php
	class navbar{
		public function nav(){
?>
<nav class="navbar navbar-expand-md navbar-dark bg-dark">
  <a class="navbar-brand" href="index.php">OneScreenCMS</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarsExample04">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link" href="index.php">Главная <!--<span class="sr-only">(current)</span>--></a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="titles_controller.php">Заголовки</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="bullits_controller.php">Буллиты</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="buttons_controller.php">Текст кнопки</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="questions_controller.php">Вопросы</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="answers_controller.php">Ответы</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="messengers_controller.php">Мессенджеры</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="emails_controller.php">Почта</a>
      </li>	  
	  <li class="nav-item">
        <a class="nav-link" href="users_controller.php">Пользователи (системные)</a>
      </li>      
    </ul>	
	<ul class="navbar-nav ml-auto">
		<li class="nav-item">
			<a class="nav-link" href="logout.php">Выход</a>
		</li>
    </ul>
	
  </div>
</nav>

<?php
		}
	};
?>

<?php
	class body_content {
		public function index_admin(){
?>
<div class="left">
<h1>Добро пожаловать!</h1>
<p>Добро пожаловать в систему управления сайтом! Для управления нужным разделом перейдите по ссылке.</p>
</div>
<?php
		}
	};
?>

<?php
	class footer_content {
		public function content(){
?>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script>window.jQuery || document.write('<script src="bootstrap-4.3.1-dist/js/jquery-3.5.1.slim.min.js"><\/script>')</script><script src="bootstrap-4.3.1-dist/js/bootstrap.bundle.min.js"></script>
<script>
function goBack() {
  window.history.back();
}
</script> 
</body>
</html>
<?php
		}
	};
?>
<?php
	class form {
		public function form_header($destination){
?>
<form class="form" method="post" action="<?php echo $destination;?>">
<?php
		}
		public function form_footer(){
?>			
  <button type="submit" class="btn btn-primary">Сохранить</button>
</form>
<?php
		}
	};
?>
<?php
	class user_form extends form{
		public function form_body(){			
?>
  <div class="form-group">
    <label for="username">Имя пользователя:</label>
    <input type="text" class="form-control" id="username" name="username">    
  </div>
 
  <div class="form-group">
    <label for="password">Пароль:</label>
    <input type="password" class="form-control" id="password" name="password">    
  </div>
<?php
		}
	};
?>


<!--Заголовки-->

<?php
	class title_form extends form{
		public function form_body(){			
?>
  <div class="form-group">
    <label for="destination">Назначение:</label>
	<select class="form-control" name="destination" id="destination">
		<option value="title">title</option>
		<option value="description">description</option>
		<option value="keywords">keywords</option>
	</select>
    <!--<input type="text" class="form-control" id="destination" name="destination">-->    
  </div>
 
  <div class="form-group">
    <label for="text">Текст:</label>
    <input type="text" class="form-control" id="text" name="text">    
  </div>
<?php
		}
	};
?>

<?php
	class edit_title_form extends form {
		public function form_body($result){
			while ($row=$result->fetch()){
?>	
  <input type="hidden" name="titleid" value="<?php echo $row['id'];?>">  
  <div class="form-group">
    <label for="destination">Назначение:</label> <br />
	<?php echo $row['destination'];?><br /><br />
	<select class="form-control" name="destination" id="destination">
		<option value="title">title</option>
		<option value="description">description</option>
		<option value="keywords">keywords</option>
	</select>        
  </div>  
  <div class="form-group">
    <label for="text">Текст:</label>
    <input type="text" class="form-control" id="text" name="text" value="<?php echo $row['text'];?>">    
  </div>  
<?php
			}
		}
	};
?>

<?php
	class view_titles {
		
		public function options(){
?>
<div class="left">
	<a href="titles_controller.php?param=create_form">Создать заголовок</a>
</div>
<?php
		}
		public function titles($result){
?>
<div class="left">
<table class="table table-bordered table-hover">
	<thead class="thead-inverse">
		<tr>
			<th>Id Заголовка</th>
			<th>Назначение</th>
			<th>Текст</th>
			<!--<th>Пароль</th>-->
			<th colspan=2 align="center">Действия</th>
		</tr>
	</thead>
<?php
			while ($row=$result->fetch()){
				echo '<tr><td>'.$row['id'].
				'</td><td>'.$row['destination'].
				'</td><td>'.$row['text'].
				'</td><td>
				<form method="post" action="titles_controller.php?param=edit_form">
					<input type="hidden" name="titleid" value='.$row['id'].'>
					<button class="btn btn-sm btn-outline-primary" type="submit">Редактировать</button>
				</form></td><td>'.
				'<form method="post" action="titles_controller.php?param=delete">
					<input type="hidden" name="titleid" value='.$row['id'].'>
					<button class="btn btn-sm btn-outline-danger" type="submit">Удалить</button>
				</form></td></tr>';
			}
?>
</div>
</table>
<?php
		}
	};
?>


<!--Буллиты-->

<?php
	class bullits_form extends form{
		public function form_body(){			
?>
  <div class="form-group">
    <label for="destination">Назначение:</label>
    <select class="form-control" name="destination" id="destination">
		<option value="index">index</option>
		<option value="thanks">thanks</option>		
	</select>    
  </div>  
  <div class="form-group">
    <label for="text">Текст:</label>
    <input type="text" class="form-control" id="text" name="text">    
  </div>
<?php
		}
	};
?>

<?php
	class edit_bullits_form extends form {
		public function form_body($result){
			while ($row=$result->fetch()){
?>	
  <input type="hidden" name="bullitid" value="<?php echo $row['id'];?>">
  <div class="form-group">  
    <label for="destination">Назначение:</label> <br />
	<?php echo $row['destination'];?><br /><br />
	<select class="form-control" name="destination" id="destination">
		<option value="index">index</option>
		<option value="thanks">thanks</option>		
	</select>
  </div>    
  <div class="form-group">
    <label for="text">Текст:</label>
    <input type="text" class="form-control" id="text" name="text" value="<?php echo $row['text'];?>">    
  </div>  
<?php
			}
		}
	};
?>

<?php
	class view_bullits {
		
		public function options(){
?>
<div class="left">
	<a href="bullits_controller.php?param=create_form">Создать буллит</a>
</div>
<?php
		}
		public function bullits($result){
?>
<div class="left">
<table class="table table-bordered table-hover">
	<thead class="thead-inverse">
		<tr>
			<th>Id Буллита</th>
			<th>Назначение</th>			
			<th>Текст</th>
			<!--<th>Пароль</th>-->
			<th colspan=2 align="center">Действия</th>
		</tr>
	</thead>
<?php
			while ($row=$result->fetch()){
				echo '<tr><td>'.$row['id'].
				'</td><td>'.$row['destination'].				
				'</td><td>'.$row['text'].
				'</td><td>
				<form method="post" action="bullits_controller.php?param=edit_form">
					<input type="hidden" name="bullitid" value='.$row['id'].'>
					<button class="btn btn-sm btn-outline-primary" type="submit">Редактировать</button>
				</form></td><td>'.
				'<form method="post" action="bullits_controller.php?param=delete">
					<input type="hidden" name="bullitid" value='.$row['id'].'>
					<button class="btn btn-sm btn-outline-danger" type="submit">Удалить</button>
				</form></td></tr>';
			}
?>
</div>
</table>
<?php
		}
	};
?>


<!--Кнопки-->

<?php
	class buttons_form extends form{
		public function form_body(){			
?>
   
  <div class="form-group">
    <label for="text">Текст:</label>
    <input type="text" class="form-control" id="text" name="text">    
  </div>
<?php
		}
	};
?>

<?php
	class edit_buttons_form extends form {
		public function form_body($result){
			while ($row=$result->fetch()){
?>	
  <input type="hidden" name="buttonid" value="<?php echo $row['id'];?>">  
  <div class="form-group">
    <label for="text">Текст:</label>
    <input type="text" class="form-control" id="text" name="text" value="<?php echo $row['text'];?>">    
  </div>  
<?php
			}
		}
	};
?>

<?php
	class view_buttons {
		
		public function options(){
?>
<div class="left">
	<a href="buttons_controller.php?param=create_form">Создать текст кнопки</a>
</div>
<?php
		}
		public function buttons($result){
?>
<div class="left">
<table class="table table-bordered table-hover">
	<thead class="thead-inverse">
		<tr>
			<th>Id Кнопки</th>			
			<th>Текст</th>
			<!--<th>Пароль</th>-->
			<th colspan=2 align="center">Действия</th>
		</tr>
	</thead>
<?php
			while ($row=$result->fetch()){
				echo '<tr><td>'.$row['id'].				
				'</td><td>'.$row['text'].
				'</td><td>
				<form method="post" action="buttons_controller.php?param=edit_form">
					<input type="hidden" name="buttonid" value='.$row['id'].'>
					<button class="btn btn-sm btn-outline-primary" type="submit">Редактировать</button>
				</form></td><td>'.
				'<form method="post" action="buttons_controller.php?param=delete">
					<input type="hidden" name="buttonid" value='.$row['id'].'>
					<button class="btn btn-sm btn-outline-danger" type="submit">Удалить</button>
				</form></td></tr>';
			}
?>
</div>
</table>
<?php
		}
	};
?>


<!--Вопросы-->

<?php
	class questions_form extends form{
		public function form_body(){			
?>
   
  <div class="form-group">
    <label for="text">Текст:</label>
    <input type="text" class="form-control" id="text" name="text">    
  </div>
<?php
		}
	};
?>

<?php
	class edit_questions_form extends form {
		public function form_body($result){
			while ($row=$result->fetch()){
?>	
  <input type="hidden" name="questionid" value="<?php echo $row['id'];?>">  
  <div class="form-group">
    <label for="text">Текст:</label>
    <input type="text" class="form-control" id="text" name="text" value="<?php echo $row['text'];?>">    
  </div>  
<?php
			}
		}
	};
?>

<?php
	class view_questions {
		
		public function options(){
?>
<div class="left">
	<a href="questions_controller.php?param=create_form">Создать вопрос</a>
</div>
<?php
		}
		public function questions($result){
?>
<div class="left">
<table class="table table-bordered table-hover">
	<thead class="thead-inverse">
		<tr>
			<th>Id Кнопки</th>			
			<th>Текст</th>
			<!--<th>Пароль</th>-->
			<th colspan=2 align="center">Действия</th>
		</tr>
	</thead>
<?php
			while ($row=$result->fetch()){
				echo '<tr><td>'.$row['id'].				
				'</td><td>'.$row['text'].
				'</td><td>
				<form method="post" action="questions_controller.php?param=edit_form">
					<input type="hidden" name="questionid" value='.$row['id'].'>
					<button class="btn btn-sm btn-outline-primary" type="submit">Редактировать</button>
				</form></td><td>'.
				'<form method="post" action="questions_controller.php?param=delete">
					<input type="hidden" name="questionid" value='.$row['id'].'>
					<button class="btn btn-sm btn-outline-danger" type="submit">Удалить</button>
				</form></td></tr>';
			}
?>
</div>
</table>
<?php
		}
	};
?>


<!--ответы-->

<?php
	class answers_form extends form {
		public function form_body($result){
?>	 
  <div class="form-group">
    <label for="question">Вопрос:</label>
    <select class="form-control" id="questionid" name="questionid">
		<option value="" selected>Вопрос</option>
<?php			
			while ($row=$result->fetch()){				
				echo '<option value="'.$row["id"].'">'.$row['text'].'</option>';				
			}
?> 
	</select>
  </div>
  <div class="form-group">
    <label for="text">Ответ:</label>
    <input type="text" class="form-control" id="text" name="text">    
  </div>  
<?php
		}
	};
?>

<?php
	class edit_answers_form extends form {
		public function form_body($result){
			while ($row=$result->fetch()){
?>	
  <input type="hidden" name="answerid" value="<?php echo $row['id'];?>">  
  <div class="form-group">
    <label for="text">Текст:</label>
    <input type="text" class="form-control" id="text" name="text" value="<?php echo $row['text'];?>">    
  </div>  
<?php
			}
		}
	};
?>

<?php
	class view_answers {
		
		public function options(){
?>
<div class="left">
	<a href="answers_controller.php?param=create_form">Создать ответ</a>
</div>
<?php
		}
		public function answers($result){
?>
<div class="left">
<table class="table table-bordered table-hover">
	<thead class="thead-inverse">
		<tr>
			<th>Id ответа</th>
			<th>Id Вопроса</th>			
			<th>Текст</th>			
			<th colspan=2 align="center">Действия</th>
		</tr>
	</thead>
<?php
			while ($row=$result->fetch()){
				echo '<tr><td>'.$row['id'].
				'</td><td>'.$row['questionId'].
				'</td><td>'.$row['text'].
				'</td><td>
				<form method="post" action="answers_controller.php?param=edit_form">
					<input type="hidden" name="answerid" value='.$row['id'].'>
					<button class="btn btn-sm btn-outline-primary" type="submit">Редактировать</button>
				</form></td><td>'.
				'<form method="post" action="answers_controller.php?param=delete">
					<input type="hidden" name="answerid" value='.$row['id'].'>
					<button class="btn btn-sm btn-outline-danger" type="submit">Удалить</button>
				</form></td></tr>';
			}
?>
</div>
</table>
<?php
		}
	};
?>


<!--Мессенджеры-->

<?php
	class messengers_form extends form{
		public function form_body(){			
?>
  <div class="form-group">
    <label for="status">Статус:</label>
	<select class="form-control" name="status" id="status">
		<option value="active">Active</option>
		<option value="disabled">Disabled</option>
		<!--<option value="keywords">keywords</option>-->
	</select>
    <!--<input type="text" class="form-control" id="destination" name="destination">-->    
  </div>
 
  <div class="form-group">
    <label for="text">Ссылка:</label>
    <input type="text" class="form-control" id="text" name="text">    
  </div>
  <div class="form-group">
    <label for="text">Изображнение:</label>
    <input type="text" class="form-control" id="img" name="img">    
  </div>
<?php
		}
	};
?>

<?php
	class edit_messenger_form extends form {
		public function form_body($result){
			while ($row=$result->fetch()){
?>	
  <input type="hidden" name="messengerid" value="<?php echo $row['id'];?>">  
  <div class="form-group">
    <label for="status">Статус:</label><br />
    <?php echo $row['status'];?><br /><br />
	<select class="form-control" name="status" id="status">
		<option value="active">Active</option>
		<option value="disabled">Disabled</option>
		<!--<option value="keywords">keywords</option>-->
	</select>	
  </div>  
  <div class="form-group">
    <label for="text">Ссылка:</label>
    <input type="text" class="form-control" id="text" name="text" value="<?php echo $row['text'];?>">    
  </div> 
  <div class="form-group">
    <label for="text">Изображение:</label>
    <input type="text" class="form-control" id="img" name="img" value="<?php echo $row['img'];?>">    
  </div>   
<?php
			}
		}
	};
?>

<?php
	class view_messengers {
		
		public function options(){
?>
<div class="left">
	<a href="messengers_controller.php?param=create_form">Создать мессенджер</a>
</div>
<?php
		}
		public function messengers($result){
?>
<div class="left">
<table class="table table-bordered table-hover">
	<thead class="thead-inverse">
		<tr>
			<th>Id Мессенджера</th>
			<th>Статус</th>
			<th>Ссылка</th>
			<th>Изображение</th>
			<!--<th>Пароль</th>-->
			<th colspan=2 align="center">Действия</th>
		</tr>
	</thead>
<?php
			while ($row=$result->fetch()){
				echo '<tr><td>'.$row['id'].
				'</td><td>'.$row['status'].
				'</td><td>'.$row['text'].
				'</td><td>'.$row['img'].
				'</td><td>
				<form method="post" action="messengers_controller.php?param=edit_form">
					<input type="hidden" name="messengerid" value='.$row['id'].'>
					<button class="btn btn-sm btn-outline-primary" type="submit">Редактировать</button>
				</form></td><td>'.
				'<form method="post" action="messengers_controller.php?param=delete">
					<input type="hidden" name="messengerid" value='.$row['id'].'>
					<button class="btn btn-sm btn-outline-danger" type="submit">Удалить</button>
				</form></td></tr>';
			}
?>
</div>
</table>
<?php
		}
	};
?>


<!--emails-->

<?php
	class emails_form extends form{
		public function form_body(){			
?>
   
  <div class="form-group">
    <label for="text">Текст:</label>
    <input type="text" class="form-control" id="text" name="text">    
  </div>
<?php
		}
	};
?>

<?php
	class edit_emails_form extends form {
		public function form_body($result){
			while ($row=$result->fetch()){
?>	
  <input type="hidden" name="emailid" value="<?php echo $row['id'];?>">  
  <div class="form-group">
    <label for="text">Текст:</label>
    <input type="text" class="form-control" id="text" name="text" value="<?php echo $row['text'];?>">    
  </div>  
<?php
			}
		}
	};
?>

<?php
	class view_emails {
		
		public function options(){
?>
<div class="left">
	<a href="emails_controller.php?param=create_form">Создать email</a>
</div>
<?php
		}
		public function emails($result){
?>
<div class="left">
<table class="table table-bordered table-hover">
	<thead class="thead-inverse">
		<tr>
			<th>Id email</th>			
			<th>Email</th>
			<!--<th>Пароль</th>-->
			<th colspan=2 align="center">Действия</th>
		</tr>
	</thead>
<?php
			while ($row=$result->fetch()){
				echo '<tr><td>'.$row['id'].				
				'</td><td>'.$row['text'].
				'</td><td>
				<form method="post" action="emails_controller.php?param=edit_form">
					<input type="hidden" name="emailid" value='.$row['id'].'>
					<button class="btn btn-sm btn-outline-primary" type="submit">Редактировать</button>
				</form></td><td>'.
				'<form method="post" action="emails_controller.php?param=delete">
					<input type="hidden" name="emailid" value='.$row['id'].'>
					<button class="btn btn-sm btn-outline-danger" type="submit">Удалить</button>
				</form></td></tr>';
			}
?>
</div>
</table>
<?php
		}
	};
?>

<?php
	class view_users {
		
		public function options(){
?>
<div class="left">
	<a href="users_controller.php?param=create_form">Создать пользователя</a>
</div>
<?php
		}
		public function users($result){
?>
<div class="left">
<table class="table table-bordered table-hover">
	<thead class="thead-inverse">
		<tr>
			<th>Id Пользователя</th>
			<th>Имя пользователя</th>
			<!--<th>Пароль</th>-->
			<th colspan=2 align="center">Действия</th>
		</tr>
	</thead>
<?php
			while ($row=$result->fetch()){
				echo '<tr><td>'.$row['id'].
				'</td><td>'.$row['login'].
				'</td><td>'.
				'<form method="post" action="users_controller.php?param=delete">
					<input type="hidden" name="userid" value='.$row['id'].'>
					<button class="btn btn-sm btn-outline-danger" type="submit">Удалить</button>
				</form></td></tr>';
			}
?>
</div>
</table>
<?php
		}
	};
?>





<?php
	class admin_url{
		public function url($destination, $urltext){
?>
<div class="left">
<a href="<?php echo $destination;?>"><?php echo $urltext;?></a>
</div>
<?php
		}
	};
?>
			