<?php
	require_once 'db_connect.php';
	class auth {
		
		public function login ($username, $password){
			$connect=new db_connect;
			$connect=$connect->connect();
			if (!$connect){
				return 0;
			}				
			$result=$connect->prepare("select * from `users` where `login`='$username' and `pass`=sha1('$password')");
			if (!$result->execute()){
				return 0;
			}
			if ($result->rowCount()>0){
				return 1;
			}
			else{
				return 0;
			}		
		}
		public function check_admin_user(){
			if (isset($_SESSION['admin_user'])){
				return true;
			}
			else{
				return FALSE;
			}
		}
	}		
?>