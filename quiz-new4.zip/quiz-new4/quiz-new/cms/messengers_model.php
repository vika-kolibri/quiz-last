<?php 
	class messengers_model{
		public function select_messengers($connect){
			$select=$connect->prepare("select * from `messengers`");
			if (!$select->execute())
				return 0;
			return $select;
		}
		public function select_messenger_by_id($connect, $messengerid){
			$select=$connect->prepare("select * from `messengers` where `id`='$messengerid'");
			if (!$select->execute())
				return 0;
			return $select;
		}
		public function create_messenger($connect, $status, $text, $img){
			$insert=$connect->prepare("insert into `messengers` (status, text, img) values ('$status', '$text', '$img')");
			if (!$insert->execute()) {
				return 0;
			} else {
				return 1;
			}			
		}
		public function edit_messenger($connect, $messengerid, $status, $text, $img){
			$update=$connect->prepare("update `messengers` set `status`='$status', `text`='$text', `img`='$img' where `id`='$messengerid'");
			if (!$update->execute())
				return 0;
			return 1;
		}		
		public function delete_messenger($connect, $messengerid){
			$delete=$connect->prepare("delete from `messengers` where `id`='$messengerid'");
			if (!$delete->execute())
				return 0;
			return 1;
		}		
	}
?>			