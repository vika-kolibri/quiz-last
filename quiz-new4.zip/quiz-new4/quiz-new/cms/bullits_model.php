<?php 
	class bullits_model{
		public function select_bullits($connect){
			$select=$connect->prepare("select * from `bullits`");
			if (!$select->execute())
				return 0;
			return $select;
		}
		public function select_bullit_by_id($connect, $bullitid){
			$select=$connect->prepare("select * from `bullits` where `id`='$bullitid'");
			if (!$select->execute())
				return 0;
			return $select;
		}
		public function create_bullit($connect, $destination, $text){
			$insert=$connect->prepare("insert into `bullits` (destination, text) values ('$destination','$text')");
			if (!$insert->execute()) {
				return 0;
			} else {
				return 1;
			}			
		}
		public function edit_bullit($connect, $bullitid, $destination, $text){
			$update=$connect->prepare("update `bullits` set `destination`='$destination',`text`='$text' where `id`='$bullitid'");
			if (!$update->execute())
				return 0;
			return 1;
		}		
		public function delete_bullit($connect, $bullitid){
			$delete=$connect->prepare("delete from `bullits` where `id`='$bullitid'");
			if (!$delete->execute())
				return 0;
			return 1;
		}		
	}
?>			