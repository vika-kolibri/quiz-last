<?php 
	class answers_model{
		
		public function select_answer($connect){			
			$select=$connect->prepare("select * from `answers`");
			if (!$select->execute())
				return 0;
			return $select;
		}		
		public function select_question_answer($connect){			
			$select=$connect->prepare("select * from `questions`");
			if (!$select->execute())
				return 0;
			return $select;
		}		
		public function select_answer_by_id($connect, $answerid){
			$select=$connect->prepare("select * from `answers` where `id`='$answerid'");
			if (!$select->execute())
				return 0;
			return $select;
		}		
		public function create_answer($connect, $questionid, $answer){			
			$insert=$connect->prepare("insert into `answers` (questionId, text) values ('$questionid', '$answer')");
			if (!$insert->execute()) {
				return 0;
			} else {
				return 1;
			}			
		}		
		public function edit_answer($connect, $answerid, $text){
			$update=$connect->prepare("update `answers` set `text`='$text' where `id`='$answerid'");
			if (!$update->execute())
				return 0;
			return 1;
		}
		public function delete_answer($connect, $answerid){
			$delete=$connect->prepare("delete from `answers` where `id`='$answerid'");
			if (!$delete->execute())
				return 0;
			return 1;
		}		
	}
?>			