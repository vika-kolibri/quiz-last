<?php 
	class buttons_model{
		public function select_buttons($connect){
			$select=$connect->prepare("select * from `buttons`");
			if (!$select->execute())
				return 0;
			return $select;
		}
		public function select_button_by_id($connect, $buttonid){
			$select=$connect->prepare("select * from `buttons` where `id`='$buttonid'");
			if (!$select->execute())
				return 0;
			return $select;
		}
		public function create_button($connect, $text){
			$insert=$connect->prepare("insert into `buttons` (text) values ('$text')");
			if (!$insert->execute()) {
				return 0;
			} else {
				return 1;
			}			
		}
		public function edit_button($connect, $buttonid, $text){
			$update=$connect->prepare("update `buttons` set `text`='$text' where `id`='$buttonid'");
			if (!$update->execute())
				return 0;
			return 1;
		}		
		public function delete_button($connect, $buttonid){
			$delete=$connect->prepare("delete from `buttons` where `id`='$buttonid'");
			if (!$delete->execute())
				return 0;
			return 1;
		}		
	}
?>			