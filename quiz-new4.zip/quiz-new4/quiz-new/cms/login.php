<?php	
	require_once ('includes/content.php');	
	$login=new loginForm;
	$login->form();	
?>