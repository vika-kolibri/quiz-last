<?php
session_start();
	require_once('includes/db_connect.php');
	require_once('includes/content.php');
	require_once('messengers_model.php');
	require_once('includes/auth.php');
	
	$check=new auth;
	$check=$check->check_admin_user();
	$header=new header_content;
	$footer=new footer_content;
	
	if ($check){	
		$connect=new db_connect;		
		$messengers=new view_messengers;
		$messengers_options=new messengers_model;
		$navbar=new navbar;
		$url=new admin_url;
		$connect=$connect->connect();
		if (!$connect){
			$header->content();
			echo "Error!";
			$footer->content();
		} else {
			$param=htmlspecialchars(strip_tags($_GET['param']));
			$header->content();
			$navbar->nav();
			switch ($param){
				case '':
					$select=$messengers_options->select_messengers($connect);
					if (!$select){
						echo "Error!";
						break;
					} else {
						$messengers->options();
						$messengers->messengers($select);
					}
				break;
				case 'create_form':
					$form=new messengers_form;
					$form->form_header('messengers_controller.php?param=create');
					$form->form_body ();
					$form->form_footer();
				break;
				case 'create':
					$status=htmlspecialchars(strip_tags($_POST['status']));
					$text=htmlspecialchars(strip_tags($_POST['text']));
					$img=htmlspecialchars(strip_tags($_POST['img']));
					$insert=$messengers_options->create_messenger($connect, $status, $text, $img);
					if (!$insert){
						echo "Error!";
					} else {
						echo '<div class="left">Мессенджер создан!</div>';
						$url->url('messengers_controller.php', 'Назад');
					}
				break;
				
				case 'edit_form':
					$form=new edit_messenger_form;
					$messengerid=htmlspecialchars(strip_tags($_POST['messengerid']));
					$select=$messengers_options->select_messenger_by_id($connect, $messengerid);
					if (!$select){
						echo "Error!";
				break;
					} else {
						$form->form_header('messengers_controller.php?param=edit');
						$form->form_body ($select);
						$form->form_footer();
					}
				break;
				case 'edit':
					$messengerid=htmlspecialchars(strip_tags($_POST['messengerid']));
					$status=htmlspecialchars(strip_tags($_POST['status']));
					$text=htmlspecialchars(strip_tags($_POST['text']));
					$img=htmlspecialchars(strip_tags($_POST['img']));
					//$catdescription=htmlspecialchars(strip_tags($_POST['catdescription']));
					$update=$messengers_options->edit_messenger($connect, $messengerid, $status, $text, $img);
					if (!$update){
						echo "Error!";
					} else {
						echo '<div class="left">Мессенджер отредактирован!</div>';
						$url->url('messengers_controller.php', 'Назад');
					}
				break;
				
				case 'delete':
					$messengerid=htmlspecialchars(strip_tags($_POST['messengerid']));
					$delete=$messengers_options->delete_messenger($connect, $messengerid);
					if (!$delete){
						echo "Error!";
					} else {
						echo '<div class="left">Мессенджер удален!</div>';
						$url->url('messengers_controller.php', 'Назад');
					}
				break;
				default:
					echo "Wrong arg!";
				break;
			}
			$footer->content();
		}
	} else {
		$header->content();
		echo '<center><h3>У Вас нет прав для просмотра этой страницы!</h3></br><a href="login.php">Вход</a></center>';		
		$footer->content();
	}
?>