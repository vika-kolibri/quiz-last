<?php 
	class questions_model{
		public function select_questions($connect){
			$select=$connect->prepare("select * from `questions`");
			if (!$select->execute())
				return 0;
			return $select;
		}
		public function select_question_by_id($connect, $questionid){
			$select=$connect->prepare("select * from `questions` where `id`='$questionid'");
			if (!$select->execute())
				return 0;
			return $select;
		}
		public function create_question($connect, $text){
			$insert=$connect->prepare("insert into `questions` (text) values ('$text')");
			if (!$insert->execute()) {
				return 0;
			} else {
				return 1;
			}			
		}
		public function edit_question($connect, $questionid, $text){
			$update=$connect->prepare("update `questions` set `text`='$text' where `id`='$questionid'");
			if (!$update->execute())
				return 0;
			return 1;
		}		
		public function delete_question($connect, $questionid){
			$delete=$connect->prepare("delete from `questions` where `id`='$questionid'");
			if (!$delete->execute())
				return 0;
			return 1;
		}		
	}
?>			