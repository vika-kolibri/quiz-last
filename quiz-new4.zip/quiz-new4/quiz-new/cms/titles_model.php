<?php 
	class titles_model{
		public function select_titles($connect){
			$select=$connect->prepare("select * from `titles`");
			if (!$select->execute())
				return 0;
			return $select;
		}
		public function select_title_by_id($connect, $titleid){
			$select=$connect->prepare("select * from `titles` where `id`='$titleid'");
			if (!$select->execute())
				return 0;
			return $select;
		}
		public function create_title($connect, $destination, $text){
			$insert=$connect->prepare("insert into `titles` (destination, text) values ('$destination', '$text')");
			if (!$insert->execute()) {
				return 0;
			} else {
				return 1;
			}			
		}
		public function edit_title($connect, $titleid, $destination, $text){
			$update=$connect->prepare("update `titles` set `destination`='$destination', `text`='$text' where `id`='$titleid'");
			if (!$update->execute())
				return 0;
			return 1;
		}		
		public function delete_title($connect, $titleid){
			$delete=$connect->prepare("delete from `titles` where `id`='$titleid'");
			if (!$delete->execute())
				return 0;
			return 1;
		}		
	}
?>			