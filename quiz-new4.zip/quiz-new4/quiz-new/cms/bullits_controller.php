<?php
session_start();
	require_once('includes/db_connect.php');
	require_once('includes/content.php');
	require_once('bullits_model.php');
	require_once('includes/auth.php');
	
	$check=new auth;
	$check=$check->check_admin_user();
	$header=new header_content;
	$footer=new footer_content;
	
	if ($check){	
		$connect=new db_connect;		
		$bullits=new view_bullits;
		$bullits_options=new bullits_model;
		$navbar=new navbar;
		$url=new admin_url;
		$connect=$connect->connect();
		if (!$connect){
			$header->content();
			echo "Error!";
			$footer->content();
		} else {
			$param=htmlspecialchars(strip_tags($_GET['param']));
			$header->content();
			$navbar->nav();
			switch ($param){
				case '':
					$select=$bullits_options->select_bullits($connect);
					if (!$select){
						echo "Error!";
						break;
					} else {
						$bullits->options();
						$bullits->bullits($select);
					}
				break;
				case 'create_form':
					$form=new bullits_form;
					$form->form_header('bullits_controller.php?param=create');
					$form->form_body ();
					$form->form_footer();
				break;
				case 'create':
					$destination=htmlspecialchars(strip_tags($_POST['destination']));
					$text=htmlspecialchars(strip_tags($_POST['text']));
					$insert=$bullits_options->create_bullit($connect, $destination, $text);
					if (!$insert){
						echo "Error!";
					} else {
						echo '<div class="left">Буллит создан!</div>';
						$url->url('bullits_controller.php', 'Назад');
					}
				break;
				
				case 'edit_form':
					$form=new edit_bullits_form;
					$bullitid=htmlspecialchars(strip_tags($_POST['bullitid']));
					$select=$bullits_options->select_bullit_by_id($connect, $bullitid);
					if (!$select){
						echo "Error!";
				break;
					} else {
						$form->form_header('bullits_controller.php?param=edit');
						$form->form_body ($select);
						$form->form_footer();
					}
				break;
				case 'edit':
					$bullitid=htmlspecialchars(strip_tags($_POST['bullitid']));
					$destination=htmlspecialchars(strip_tags($_POST['destination']));
					$text=htmlspecialchars(strip_tags($_POST['text']));
					//$catdescription=htmlspecialchars(strip_tags($_POST['catdescription']));
					$update=$bullits_options->edit_bullit($connect, $bullitid, $destination, $text);
					if (!$update){
						echo "Error!";
					} else {
						echo '<div class="left">Буллит отредактирован!</div>';
						$url->url('bullits_controller.php', 'Назад');
					}
				break;
				
				case 'delete':
					$bullitid=htmlspecialchars(strip_tags($_POST['bullitid']));
					$delete=$bullits_options->delete_bullit($connect, $bullitid);
					if (!$delete){
						echo "Error!";
					} else {
						echo '<div class="left">Буллит удален!</div>';
						$url->url('bullits_controller.php', 'Назад');
					}
				break;
				default:
					echo "Wrong arg!";
				break;
			}
			$footer->content();
		}
	} else {
		$header->content();
		echo '<center><h3>У Вас нет прав для просмотра этой страницы!</h3></br><a href="login.php">Вход</a></center>';		
		$footer->content();
	}
?>