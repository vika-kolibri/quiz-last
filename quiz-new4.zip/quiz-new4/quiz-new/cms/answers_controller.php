<?php
session_start();
	require_once('includes/db_connect.php');
	require_once('includes/content.php');
	require_once('answers_model.php');
	require_once('includes/auth.php');
	
	$auth=new auth;
	$auth=$auth->check_admin_user();
	$header=new header_content;
	$footer=new footer_content;
	
	if ($auth){
		$connect=new db_connect;		
		$answers=new view_answers;
		$answers_options=new answers_model;
		$navbar=new navbar;
		$url=new admin_url;
		
		$connect=$connect->connect();
		if (!$connect){
			$header->content();
			echo 'Error! No connect to database!';
			$footer->content();
		} else {
			$param=htmlspecialchars(strip_tags($_GET['param']));
			$header->content();
			$navbar->nav();
			switch ($param){
				case '':
					$select=$answers_options->select_answer($connect);
					if (!$select){
						echo "Error!";
						break;
					} else {
						$answers->options();
						$answers->answers($select);
					}
				break;
				case 'create_form':
					$form=new answers_form;
					$select=$answers_options->select_question_answer($connect);
					if (!$select){
						echo "Error!";
						break;
					} else {
						$form->form_header('answers_controller.php?param=create');
						$form->form_body ($select);
						$form->form_footer();
					}
				break;
				case 'create':
					$questionid=htmlspecialchars(strip_tags($_POST['questionid']));
					$answer=htmlspecialchars(strip_tags($_POST['text']));					
					$insert=$answers_options->create_answer($connect, $questionid, $answer);
					if (!$insert){
						echo "Error!";
					} else {
						echo '<div class="left">Ответ создан!</div>';
						$url->url('answers_controller.php', 'Назад');
					}
				break;
				case 'edit_form':
					$form=new edit_answers_form;
					$answerid=htmlspecialchars(strip_tags($_POST['answerid']));
					$select=$answers_options->select_answer_by_id($connect, $answerid);
					if (!$select){
						echo "Error!";
				break;
					} else {
						$form->form_header('answers_controller.php?param=edit');
						$form->form_body ($select);
						$form->form_footer();
					}
				break;
				case 'edit':
					$answerid=htmlspecialchars(strip_tags($_POST['answerid']));
					$answer=htmlspecialchars(strip_tags($_POST['text']));					
					$update=$answers_options->edit_answer($connect, $answerid, $answer);
					if (!$update){
						echo "Error!";
					} else {
						echo '<div class="left">Ответ отредактирован!</div>';
						$url->url('answers_controller.php', 'Назад');
					}
				break;
				case 'delete':
					$answerid=htmlspecialchars(strip_tags($_POST['answerid']));
					$delete=$answers_options->delete_answer($connect, $answerid);
					if (!$delete){
						echo "Error!";
					} else {
						echo '<div class="left">Ответ удален!</div>';
						$url->url('answers_controller.php', 'Назад');
					}
				break;
				default:
					echo "Wrong arg!";
				break;
			}
			$footer->content();
		}
	} else {
		$header->content();
		echo '<center><h3>У Вас нет прав для просмотра этой страницы!</h3></br><a href="login.php">Вход</a></center>';		
		$footer->content();
	}
?>