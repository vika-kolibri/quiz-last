<?php
session_start();
	require_once('includes/db_connect.php');
	require_once('includes/content.php');
	require_once('emails_model.php');
	require_once('includes/auth.php');
	
	$check=new auth;
	$check=$check->check_admin_user();
	$header=new header_content;
	$footer=new footer_content;
	
	if ($check){	
		$connect=new db_connect;		
		$emails=new view_emails;
		$emails_options=new emails_model;
		$navbar=new navbar;
		$url=new admin_url;
		$connect=$connect->connect();
		if (!$connect){
			$header->content();
			echo "Error!";
			$footer->content();
		} else {
			$param=htmlspecialchars(strip_tags($_GET['param']));
			$header->content();
			$navbar->nav();
			switch ($param){
				case '':
					$select=$emails_options->select_emails($connect);
					if (!$select){
						echo "Error!";
						break;
					} else {
						$emails->options();
						$emails->emails($select);
					}
				break;
				case 'create_form':
					$form=new emails_form;
					$form->form_header('emails_controller.php?param=create');
					$form->form_body ();
					$form->form_footer();
				break;
				case 'create':
					//$destination=htmlspecialchars(strip_tags($_POST['destination']));
					$text=htmlspecialchars(strip_tags($_POST['text']));
					$insert=$emails_options->create_email($connect, $text);
					if (!$insert){
						echo "Error!";
					} else {
						echo '<div class="left">email создан!</div>';
						$url->url('emails_controller.php', 'Назад');
					}
				break;
				
				case 'edit_form':
					$form=new edit_emails_form;
					$emailid=htmlspecialchars(strip_tags($_POST['emailid']));
					$select=$emails_options->select_email_by_id($connect, $emailid);
					if (!$select){
						echo "Error!";
				break;
					} else {
						$form->form_header('emails_controller.php?param=edit');
						$form->form_body ($select);
						$form->form_footer();
					}
				break;
				case 'edit':
					$emailid=htmlspecialchars(strip_tags($_POST['emailid']));
					//$destination=htmlspecialchars(strip_tags($_POST['destination']));
					$text=htmlspecialchars(strip_tags($_POST['text']));
					//$catdescription=htmlspecialchars(strip_tags($_POST['catdescription']));
					$update=$emails_options->edit_email($connect, $emailid, $text);
					if (!$update){
						echo "Error!";
					} else {
						echo '<div class="left">email отредактирован!</div>';
						$url->url('emails_controller.php', 'Назад');
					}
				break;
				
				case 'delete':
					$emailid=htmlspecialchars(strip_tags($_POST['emailid']));
					$delete=$emails_options->delete_email($connect, $emailid);
					if (!$delete){
						echo "Error!";
					} else {
						echo '<div class="left">email удален!</div>';
						$url->url('emails_controller.php', 'Назад');
					}
				break;
				default:
					echo "Wrong arg!";
				break;
			}
			$footer->content();
		}
	} else {
		$header->content();
		echo '<center><h3>У Вас нет прав для просмотра этой страницы!</h3></br><a href="login.php">Вход</a></center>';		
		$footer->content();
	}
?>