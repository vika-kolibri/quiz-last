<?php 
	class emails_model{
		public function select_emails($connect){
			$select=$connect->prepare("select * from `emails`");
			if (!$select->execute())
				return 0;
			return $select;
		}
		public function select_email_by_id($connect, $emailid){
			$select=$connect->prepare("select * from `emails` where `id`='$emailid'");
			if (!$select->execute())
				return 0;
			return $select;
		}
		public function create_email($connect, $text){
			$insert=$connect->prepare("insert into `emails` (text) values ('$text')");
			if (!$insert->execute()) {
				return 0;
			} else {
				return 1;
			}			
		}
		public function edit_email($connect, $emailid, $text){
			$update=$connect->prepare("update `emails` set `text`='$text' where `id`='$emailid'");
			if (!$update->execute())
				return 0;
			return 1;
		}		
		public function delete_email($connect, $emailid){
			$delete=$connect->prepare("delete from `emails` where `id`='$emailid'");
			if (!$delete->execute())
				return 0;
			return 1;
		}		
	}
?>			